<template>
  <div class="app-shell">
    <header class="header">
      <div class="header-content">
        <h1>FlexZone Fitness</h1>
        <p class="tagline">Manage your group fitness schedule</p>
      </div>
      <div class="header-stat">
        <span class="stat-label">Active sessions</span>
        <strong class="stat-count">{{ totalSessions }}</strong>
      </div>
    </header>

    <section class="form-section">
      <h2>Add a New Class</h2>
      <form @submit.prevent="addSession" class="session-form">
        <div class="form-group">
          <label for="className">Class Name</label>
          <input
            id="className"
            v-model="formData.name"
            type="text"
            placeholder="e.g., Morning Yoga"
            required
          />
        </div>

        <div class="form-group">
          <label for="coach">Coach/Instructor</label>
          <input
            id="coach"
            v-model="formData.coach"
            type="text"
            placeholder="e.g., Sarah"
            required
          />
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="date">Date</label>
            <input id="date" v-model="formData.date" type="date" required />
          </div>
          <div class="form-group">
            <label for="time">Time</label>
            <input id="time" v-model="formData.time" type="time" required />
          </div>
        </div>

        <div class="form-group">
          <label for="capacity">Class Capacity</label>
          <input
            id="capacity"
            v-model.number="formData.capacity"
            type="number"
            placeholder="e.g., 25"
            min="1"
            max="100"
            required
          />
        </div>

        <button type="submit" class="submit-btn">Add Session</button>
      </form>
    </section>

    <section class="sessions-section">
      <h2>Scheduled Sessions</h2>

      <div v-if="sessions.length === 0" class="empty-state">
        <p>No sessions scheduled yet. Add one to get started!</p>
      </div>

      <div v-else class="sessions-list">
        <SessionCard
          v-for="session in sortedSessions"
          :key="session.id"
          :session="session"
          @delete-session="deleteSession"
        />
      </div>
    </section>
  </div>
</template>

<script>
import SessionCard from './components/CourseCard.vue';

export default {
  name: 'App',
  components: { SessionCard },
  data() {
    return {
      sessions: [],
      nextId: 1,
      formData: {
        name: '',
        coach: '',
        date: '',
        time: '',
        capacity: ''
      }
    };
  },
  computed: {
    totalSessions() {
      return this.sessions.length;
    },
    sortedSessions() {
      return [...this.sessions].sort((a, b) => {
        const dateA = new Date(`${a.date}T${a.time}`);
        const dateB = new Date(`${b.date}T${b.time}`);
        return dateA - dateB;
      });
    }
  },
  methods: {
    addSession() {
      if (
        !this.formData.name.trim() ||
        !this.formData.coach.trim() ||
        !this.formData.date ||
        !this.formData.time ||
        !this.formData.capacity
      ) {
        alert('Please fill in all fields correctly.');
        return;
      }

      this.sessions.push({
        id: this.nextId++,
        name: this.formData.name,
        coach: this.formData.coach,
        date: this.formData.date,
        time: this.formData.time,
        capacity: this.formData.capacity
      });

      this.formData = {
        name: '',
        coach: '',
        date: '',
        time: '',
        capacity: ''
      };
    },
    deleteSession(sessionId) {
      this.sessions = this.sessions.filter((session) => session.id !== sessionId);
    }
  }
};
</script>

<style>
:root {
  color: #111827;
  background: #f8fafc;
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

body {
  margin: 0;
  min-height: 100vh;
  background: linear-gradient(180deg, #f8fafc 0%, #eff6ff 100%);
}

.app-shell {
  max-width: 1000px;
  margin: 0 auto;
  padding: 32px 24px;
}

.header {
  display: grid;
  gap: 24px;
  grid-template-columns: 1fr auto;
  align-items: start;
  margin-bottom: 40px;
  padding: 32px 36px;
  border-radius: 28px;
  background: #ffffff;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.08);
}

.header-content h1 {
  margin: 0 0 8px;
  font-size: clamp(2rem, 4vw, 3rem);
  line-height: 1.1;
}

.tagline {
  margin: 0;
  color: #475569;
  font-size: 1rem;
}

.header-stat {
  text-align: right;
  padding: 20px 24px;
  border-radius: 20px;
  background: #f0f9ff;
}

.stat-label {
  display: block;
  font-size: 0.9rem;
  color: #475569;
  margin-bottom: 8px;
}

.stat-count {
  display: block;
  font-size: 2.8rem;
  color: #111827;
}

.form-section {
  margin-bottom: 40px;
}

.form-section h2 {
  margin: 0 0 20px;
  font-size: 1.6rem;
  color: #111827;
}

.session-form {
  background: #ffffff;
  border-radius: 20px;
  padding: 28px;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
  display: grid;
  gap: 20px;
}

.form-group {
  display: grid;
  gap: 8px;
}

.form-group label {
  font-weight: 700;
  color: #111827;
  font-size: 0.95rem;
}

.form-group input {
  border: 1px solid #cbd5e1;
  border-radius: 12px;
  padding: 12px 14px;
  font-size: 1rem;
  outline: none;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.form-group input:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

.form-row {
  display: grid;
  gap: 20px;
  grid-template-columns: 1fr 1fr;
}

.submit-btn {
  border: none;
  background: #2563eb;
  color: #ffffff;
  border-radius: 12px;
  padding: 14px 20px;
  font-weight: 700;
  font-size: 1rem;
  cursor: pointer;
  transition: transform 0.2s ease, background-color 0.2s ease;
  grid-column: 1 / -1;
}

.submit-btn:hover {
  background: #1d4ed8;
  transform: translateY(-1px);
}

.sessions-section {
  margin-bottom: 40px;
}

.sessions-section h2 {
  margin: 0 0 20px;
  font-size: 1.6rem;
  color: #111827;
}

.empty-state {
  background: #ffffff;
  border-radius: 20px;
  padding: 48px 24px;
  text-align: center;
  color: #64748b;
  font-size: 1.1rem;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
}

.sessions-list {
  display: grid;
  gap: 20px;
}

@media (max-width: 640px) {
  .header {
    grid-template-columns: 1fr;
  }

  .header-stat {
    text-align: left;
  }

  .form-row {
    grid-template-columns: 1fr;
  }
}
</style>
