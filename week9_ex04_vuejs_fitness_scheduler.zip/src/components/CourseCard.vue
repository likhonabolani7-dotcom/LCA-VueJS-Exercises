<template>
  <div class="session-card">
    <div class="session-header">
      <div>
        <h3>{{ session.name }}</h3>
        <p class="coach">📍 Coach: {{ session.coach }}</p>
      </div>
      <button
        type="button"
        class="delete-btn"
        @click="$emit('delete-session', session.id)"
        aria-label="Delete session"
      >
        ✕
      </button>
    </div>

    <div class="session-details">
      <div class="detail-item">
        <span class="label">📅 Date</span>
        <span class="value">{{ formatDate(session.date) }}</span>
      </div>
      <div class="detail-item">
        <span class="label">⏰ Time</span>
        <span class="value">{{ session.time }}</span>
      </div>
      <div class="detail-item">
        <span class="label">👥 Capacity</span>
        <span class="value">{{ session.capacity }} participants</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SessionCard',
  props: {
    session: {
      type: Object,
      required: true
    }
  },
  methods: {
    formatDate(dateString) {
      const date = new Date(`${dateString}T00:00:00`);
      return date.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    }
  }
};
</script>

<style scoped>
.session-card {
  background: #ffffff;
  border-radius: 16px;
  padding: 20px;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  border-left: 4px solid #2563eb;
}

.session-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 22px 50px rgba(15, 23, 42, 0.12);
}

.session-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 16px;
}

.session-header h3 {
  margin: 0 0 6px;
  font-size: 1.3rem;
  color: #111827;
}

.coach {
  margin: 0;
  color: #64748b;
  font-size: 0.95rem;
}

.delete-btn {
  border: none;
  background: #fee2e2;
  color: #dc2626;
  width: 36px;
  height: 36px;
  border-radius: 8px;
  font-size: 1.2rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s ease, transform 0.2s ease;
  flex-shrink: 0;
}

.delete-btn:hover {
  background: #fecaca;
  transform: scale(1.05);
}

.session-details {
  display: grid;
  gap: 12px;
}

.detail-item {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  padding: 10px 0;
  border-top: 1px solid #f1f5f9;
}

.detail-item:first-child {
  border-top: none;
}

.label {
  color: #64748b;
  font-weight: 600;
  font-size: 0.95rem;
}

.value {
  color: #111827;
  font-weight: 700;
}

.property-type {
  margin: 0;
  color: #2563eb;
  font-weight: 700;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.property-specs {
  display: flex;
  gap: 16px;
  padding: 12px 0;
  border-top: 1px solid #e2e8f0;
  border-bottom: 1px solid #e2e8f0;
}

.spec {
  font-size: 0.95rem;
  color: #475569;
}

.spec strong {
  color: #111827;
}

.property-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-top: auto;
}

.price {
  margin: 0;
  font-size: 1.6rem;
  font-weight: 800;
}

.price-unit {
  font-size: 0.9rem;
  color: #64748b;
}

.contact-btn {
  border: none;
  background: #2563eb;
  color: #ffffff;
  border-radius: 12px;
  padding: 12px 18px;
  font-weight: 700;
  cursor: pointer;
  transition: transform 0.2s ease, background-color 0.2s ease;
}

.contact-btn:hover {
  background: #1d4ed8;
  transform: translateY(-1px);
}
</style>
