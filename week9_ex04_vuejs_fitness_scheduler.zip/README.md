# FlexZone Fitness Class Manager

A Vue 3 single-page application for managing fitness class schedules. Staff and instructors can add new sessions, view a sorted schedule, and delete classes when needed.

## Project Overview

FlexZone Fitness is digitalizing its class management process. This app lets gym staff add new fitness sessions with details like class name, instructor, date, time, and capacity. All sessions are stored locally in the browser.

## Features

- Add new fitness classes with validation
- Automatic sorting by date and time
- Real-time session count display
- Delete sessions from the schedule
- Empty state message when no sessions exist
- Responsive layout for mobile and desktop
- Form validation prevents incomplete submissions
- Clean, user-friendly interface

## Installation

1. Open a terminal in the `vue` directory.
2. Run `npm install`.
3. Run `npm run dev`.

## Run

- Start the app with `npm run dev`
- Open the local URL shown in the terminal

## Screenshot

Add a screenshot of the finished interface here:

![FlexZone Fitness Class Manager](screenshot.png)

## Notes

- All session data is stored locally in the app.
- The app is built with Vue 3 and Vite.
- Form validation is handled through Vue reactivity.
