<template>
  <div class="app-shell">
    <header class="header">
      <div class="header-content">
        <h1>Cooking Masterclass</h1>
        <p class="tagline">Online Culinary Courses</p>
      </div>
      <div class="header-stat">
        <span class="stat-label">Items in cart</span>
        <strong class="stat-count">{{ cartItemCount }}</strong>
      </div>
    </header>

    <div class="checkout-layout">
      <section class="products-section">
        <h2>Available Classes</h2>
        
        <div v-if="courses.length === 0" class="empty-state">
          <p>No courses available.</p>
        </div>

        <div v-else class="products-grid">
          <CourseCard
            v-for="course in courses"
            :key="course.id"
            :course="course"
            :is-sold-out="!course.available"
            @add-to-cart="addToCart"
          />
        </div>
      </section>

      <section class="cart-section">
        <h2>Shopping Cart</h2>

        <div v-if="cart.length === 0" class="empty-cart">
          <p>Your cart is empty</p>
        </div>

        <div v-else>
          <div class="cart-items">
            <div v-for="item in cart" :key="item.id" class="cart-item">
              <div class="item-details">
                <h4>{{ item.title }}</h4>
                <p class="item-price">R{{ item.price.toFixed(2) }}</p>
              </div>
              <div class="item-quantity">
                <button @click="decreaseQuantity(item.id)" class="qty-btn">−</button>
                <span class="qty-value">{{ item.quantity }}</span>
                <button @click="increaseQuantity(item.id)" class="qty-btn">+</button>
              </div>
              <div class="item-total">
                <p>R{{ (item.price * item.quantity).toFixed(2) }}</p>
              </div>
              <button @click="removeFromCart(item.id)" class="remove-btn">✕</button>
            </div>
          </div>

          <div class="cart-summary">
            <div class="summary-row">
              <span>Subtotal:</span>
              <span>R{{ subtotal.toFixed(2) }}</span>
            </div>
            <div class="summary-row">
              <span>Tax (10%):</span>
              <span>R{{ tax.toFixed(2) }}</span>
            </div>
            <div class="summary-row total">
              <span>Total:</span>
              <span>R{{ grandTotal.toFixed(2) }}</span>
            </div>
          </div>

          <button @click="clearCart" class="clear-btn">Clear Cart</button>
          <button class="checkout-btn">Proceed to Checkout</button>
        </div>
      </section>
    </div>
  </div>
</template>

<script>
import CourseCard from './components/CourseCard.vue';

export default {
  name: 'App',
  components: { CourseCard },
  data() {
    return {
      courses: [
        { id: 1, title: 'Modern Pasta Workshop', chef: 'Chef Amara', price: 450, level: 'Beginner', available: true },
        { id: 2, title: 'Art of Sourdough', chef: 'Chef Nia', price: 550, level: 'Intermediate', available: true },
        { id: 3, title: 'Seafood Mastery', chef: 'Chef Kofi', price: 700, level: 'Advanced', available: false },
        { id: 4, title: 'Plant-Based Bistro', chef: 'Chef Lila', price: 420, level: 'Beginner', available: true },
        { id: 5, title: 'French Pastry Basics', chef: 'Chef Pierre', price: 650, level: 'Intermediate', available: false },
        { id: 6, title: 'Spices & Sauces', chef: 'Chef Zuri', price: 500, level: 'Intermediate', available: true }
      ],
      cart: [],
      TAX_RATE: 0.10
    };
  },
  computed: {
    cartItemCount() {
      return this.cart.reduce((total, item) => total + item.quantity, 0);
    },
    subtotal() {
      return this.cart.reduce((total, item) => total + item.price * item.quantity, 0);
    },
    tax() {
      return this.subtotal * this.TAX_RATE;
    },
    grandTotal() {
      return this.subtotal + this.tax;
    }
  },
  methods: {
    addToCart(courseId) {
      const course = this.courses.find((c) => c.id === courseId);
      
      if (!course || !course.available) {
        alert('This course is not available!');
        return;
      }

      const existingItem = this.cart.find((item) => item.id === courseId);
      
      if (existingItem) {
        existingItem.quantity++;
      } else {
        this.cart.push({
          id: course.id,
          title: course.title,
          chef: course.chef,
          price: course.price,
          quantity: 1
        });
      }

      this.saveCart();
    },
    removeFromCart(courseId) {
      this.cart = this.cart.filter((item) => item.id !== courseId);
      this.saveCart();
    },
    increaseQuantity(courseId) {
      const item = this.cart.find((item) => item.id === courseId);
      if (item) {
        item.quantity++;
        this.saveCart();
      }
    },
    decreaseQuantity(courseId) {
      const item = this.cart.find((item) => item.id === courseId);
      if (item && item.quantity > 1) {
        item.quantity--;
        this.saveCart();
      } else if (item && item.quantity === 1) {
        this.removeFromCart(courseId);
      }
    },
    clearCart() {
      if (confirm('Are you sure you want to clear your cart?')) {
        this.cart = [];
        this.saveCart();
      }
    },
    saveCart() {
      localStorage.setItem('cookingCart', JSON.stringify(this.cart));
    },
    loadCart() {
      const saved = localStorage.getItem('cookingCart');
      if (saved) {
        this.cart = JSON.parse(saved);
      }
    }
  },
  mounted() {
    this.loadCart();
  }
};
</script>

<style>
:root {
  color: #111827;
  background: #f8fafc;
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

body {
  margin: 0;
  min-height: 100vh;
  background: linear-gradient(180deg, #f8fafc 0%, #eff6ff 100%);
}

.app-shell {
  max-width: 1400px;
  margin: 0 auto;
  padding: 32px 24px;
}

.header {
  display: grid;
  gap: 24px;
  grid-template-columns: 1fr auto;
  align-items: start;
  margin-bottom: 40px;
  padding: 32px 36px;
  border-radius: 28px;
  background: #ffffff;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.08);
}

.header-content h1 {
  margin: 0 0 8px;
  font-size: clamp(2rem, 4vw, 3rem);
  line-height: 1.1;
}

.tagline {
  margin: 0;
  color: #475569;
  font-size: 1rem;
}

.header-stat {
  text-align: right;
  padding: 20px 24px;
  border-radius: 20px;
  background: #f0f9ff;
}

.stat-label {
  display: block;
  font-size: 0.9rem;
  color: #475569;
  margin-bottom: 8px;
}

.stat-count {
  display: block;
  font-size: 2.8rem;
  color: #111827;
}

.checkout-layout {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 32px;
  margin-bottom: 40px;
}

.products-section h2,
.cart-section h2 {
  margin: 0 0 20px;
  font-size: 1.6rem;
  color: #111827;
}

.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
}

.empty-state {
  background: #ffffff;
  border-radius: 20px;
  padding: 48px 24px;
  text-align: center;
  color: #64748b;
  font-size: 1.1rem;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
}

.cart-section {
  background: #ffffff;
  border-radius: 20px;
  padding: 28px;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
  height: fit-content;
  position: sticky;
  top: 20px;
}

.empty-cart {
  text-align: center;
  padding: 48px 24px;
  color: #94a3b8;
  font-size: 1.1rem;
}

.cart-items {
  margin-bottom: 24px;
  border-bottom: 1px solid #e2e8f0;
  padding-bottom: 20px;
}

.cart-item {
  display: grid;
  grid-template-columns: 1fr auto auto auto;
  gap: 12px;
  align-items: center;
  padding: 16px 0;
  border-bottom: 1px solid #f1f5f9;
}

.cart-item:last-child {
  border-bottom: none;
}

.item-details h4 {
  margin: 0 0 4px;
  font-size: 0.95rem;
  color: #111827;
}

.item-price {
  margin: 0;
  color: #2563eb;
  font-weight: 700;
  font-size: 0.9rem;
}

.item-quantity {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #f8fafc;
  border-radius: 8px;
  padding: 4px;
}

.qty-btn {
  border: none;
  background: transparent;
  color: #2563eb;
  cursor: pointer;
  font-weight: 700;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  transition: background-color 0.2s ease;
}

.qty-btn:hover {
  background: #e0e7ff;
}

.qty-value {
  min-width: 24px;
  text-align: center;
  font-weight: 700;
  color: #111827;
}

.item-total {
  text-align: right;
  font-weight: 700;
  color: #111827;
}

.item-total p {
  margin: 0;
}

.remove-btn {
  border: none;
  background: #fee2e2;
  color: #dc2626;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 700;
  transition: background-color 0.2s ease;
}

.remove-btn:hover {
  background: #fecaca;
}

.cart-summary {
  margin-bottom: 20px;
  padding: 16px 0;
  border-top: 2px solid #e2e8f0;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  color: #475569;
  font-size: 0.95rem;
}

.summary-row span:last-child {
  font-weight: 700;
  color: #111827;
}

.summary-row.total {
  font-size: 1.1rem;
  color: #111827;
  border-top: 1px solid #e2e8f0;
  padding-top: 12px;
  margin-top: 12px;
}

.summary-row.total span:last-child {
  color: #2563eb;
}

.clear-btn,
.checkout-btn {
  border: none;
  border-radius: 12px;
  padding: 12px 16px;
  font-weight: 700;
  cursor: pointer;
  font-size: 0.95rem;
  width: 100%;
  transition: transform 0.2s ease, background-color 0.2s ease;
  margin-bottom: 10px;
}

.clear-btn {
  background: #f1f5f9;
  color: #475569;
}

.clear-btn:hover {
  background: #e2e8f0;
  transform: translateY(-1px);
}

.checkout-btn {
  background: #2563eb;
  color: #ffffff;
}

.checkout-btn:hover {
  background: #1d4ed8;
  transform: translateY(-1px);
}

@media (max-width: 1024px) {
  .checkout-layout {
    grid-template-columns: 1fr;
  }

  .cart-section {
    position: static;
  }
}

@media (max-width: 640px) {
  .header {
    grid-template-columns: 1fr;
  }

  .header-stat {
    text-align: left;
  }

  .products-grid {
    grid-template-columns: 1fr;
  }

  .cart-item {
    grid-template-columns: 1fr auto;
    gap: 8px;
  }

  .item-quantity,
  .item-total,
  .remove-btn {
    grid-column: 2;
  }
}
</style>
