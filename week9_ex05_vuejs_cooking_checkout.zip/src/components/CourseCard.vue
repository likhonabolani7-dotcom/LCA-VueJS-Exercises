<template>
  <div :class="['course-card', { 'sold-out': isSoldOut }]">
    <div class="card-header">
      <h3>{{ course.title }}</h3>
      <p v-if="isSoldOut" class="sold-out-badge">Sold Out</p>
    </div>

    <p class="instructor">{{ course.chef }}</p>
    <p class="level">{{ course.level }}</p>

    <div class="card-footer">
      <div class="price-section">
        <span class="price-label">Price:</span>
        <span class="price">R{{ course.price.toFixed(2) }}</span>
      </div>
      <button
        :disabled="isSoldOut"
        @click="$emit('add-to-cart', course.id)"
        :class="['add-btn', { disabled: isSoldOut }]"
      >
        {{ isSoldOut ? 'Sold Out' : 'Add to Cart' }}
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CourseCard',
  props: {
    course: {
      type: Object,
      required: true
    },
    isSoldOut: {
      type: Boolean,
      default: false
    }
  }
};
</script>

<style scoped>
.course-card {
  background: #ffffff;
  border-radius: 16px;
  padding: 20px;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
  transition: transform 0.2s ease, box-shadow 0.2s ease, opacity 0.2s ease;
  border-left: 4px solid #2563eb;
  display: flex;
  flex-direction: column;
}

.course-card:hover:not(.sold-out) {
  transform: translateY(-4px);
  box-shadow: 0 22px 50px rgba(15, 23, 42, 0.12);
}

.course-card.sold-out {
  opacity: 0.6;
  border-left-color: #cbd5e1;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 8px;
}

.card-header h3 {
  margin: 0;
  font-size: 1.2rem;
  color: #111827;
  line-height: 1.3;
}

.sold-out-badge {
  background: #fecaca;
  color: #dc2626;
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 700;
  margin: 0;
  white-space: nowrap;
}

.instructor {
  margin: 0 0 4px;
  color: #2563eb;
  font-weight: 700;
  font-size: 0.9rem;
}

.level {
  margin: 0 0 16px;
  color: #64748b;
  font-size: 0.95rem;
  line-height: 1.4;
  flex-grow: 1;
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  padding-top: 16px;
  border-top: 1px solid #f1f5f9;
}

.price-section {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.price-label {
  font-size: 0.85rem;
  color: #64748b;
  font-weight: 600;
}

.price {
  font-size: 1.4rem;
  font-weight: 700;
  color: #2563eb;
}

.add-btn {
  border: none;
  background: #2563eb;
  color: #ffffff;
  padding: 10px 16px;
  border-radius: 10px;
  font-weight: 700;
  font-size: 0.9rem;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.2s ease;
  white-space: nowrap;
}

.add-btn:hover:not(.disabled) {
  background: #1d4ed8;
  transform: translateY(-1px);
}

.add-btn.disabled {
  background: #cbd5e1;
  cursor: not-allowed;
}
</style>
