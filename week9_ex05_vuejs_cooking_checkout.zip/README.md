# Cooking Masterclass - Checkout Prototype

A Vue 3 shopping cart prototype for browsing and purchasing online cooking classes. Users can add courses to their cart, adjust quantities, remove items, and view a live price summary with tax calculation.

## Project Overview

Cooking Masterclass is developing an e-commerce platform for their culinary courses. This prototype simulates the core checkout experience, allowing users to browse a course catalogue, manage a shopping cart, and see real-time pricing updates. The app stores cart data in localStorage for persistence across page refreshes.

## Features

- Browse cooking classes with instructor names and pricing
- Add courses to cart with validation for sold-out items
- Adjust item quantities using +/- buttons
- Remove individual items from cart
- Real-time price calculations (subtotal, 10% tax, grand total)
- Line item totals for each course in cart
- "Sold Out" indicator for unavailable courses
- Disabled "Add to Cart" button for sold-out items
- Empty cart messaging
- Clear Cart button for quick reset
- Cart data persists using localStorage
- Responsive two-column layout (stacks on mobile)
- Clean, modern e-commerce UI design

## Installation

1. Open a terminal in the `vue` directory.
2. Run `npm install`.
3. Run `npm run dev`.

## Run

- Start the app with `npm run dev`
- Open the local URL shown in the terminal (typically http://localhost:5173)

## Screenshot

Add a screenshot of the finished checkout interface here:

![Cooking Masterclass Checkout](screenshot.png)

## Features in Detail

### Product Catalogue
- Grid layout displaying cooking courses
- Each course shows name, instructor, level, and price
- Stock status clearly indicated
- Sold-out courses are visually de-emphasized
- Responsive grid

### Shopping Cart
- Sticky sidebar cart on desktop
- Real-time item count in header
- Quantity adjustment controls (+/- buttons)
- Remove button for each item
- Price breakdown: Subtotal → Tax (10%) → Grand Total
- Empty state messaging
- Clear Cart and Proceed to Checkout buttons

### Data Persistence
- Cart saves to localStorage on every change
- Cart loads from localStorage on page refresh
- Seamless user experience across sessions

## Notes

- All course data and cart items are stored locally in the browser
- No backend or API integration required
- Tax rate is fixed at 10%
- The app uses Vue 3 with Vite for fast development and builds
- localStorage can be cleared using browser DevTools
- Course availability is simulated

1. Open a terminal in the `vue` directory.
2. Run `npm install`.
3. Run `npm run dev`.

## Run

- Start the app with `npm run dev`
- Open the local URL shown in the terminal

## Screenshot

Add a screenshot of the finished interface here:

![Cooking Masterclass Catalogue](screenshot.png)

## Notes

- The app is built with Vue 3 and Vite.
- No backend or external API is required.
