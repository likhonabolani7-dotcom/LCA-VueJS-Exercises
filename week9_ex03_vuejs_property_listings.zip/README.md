# Homes & Beyond Property Listings

A Vue 3 single-page application for browsing short-term property rentals in Cape Town. The app displays available properties with search and price sorting functionality.

## Project Overview

Homes & Beyond is a real-estate startup focused on short-term rentals. This app showcases property listings with essential details, allowing users to search by title or location and sort by price.

## Features

- Dynamic property listing rendering from local data
- Search functionality by property title or location
- Price sorting (low-to-high or high-to-low)
- "Not Available" badges for unavailable properties
- Bookmark functionality for favourite listings
- Available property count in header
- Responsive grid-based card layout
- Contact button placeholder on each listing

## Installation

1. Open a terminal in the `vue` directory.
2. Run `npm install`.
3. Run `npm run dev`.

## Run

- Start the app with `npm run dev`
- Open the local URL shown in the terminal

## Screenshot

Add a screenshot of the finished interface here:

![Homes & Beyond Property Listings](screenshot.png)

## Notes

- All property data is stored locally in the app.
- The app is built with Vue 3 and Vite.
- Search and sort work smoothly using Vue computed properties.
