<template>
  <article :class="['property-card', { unavailable: !property.available }]">
    <div class="property-image" :style="{ backgroundImage: property.image }"></div>

    <div v-if="!property.available" class="unavailable-badge">Not Available</div>

    <div class="property-content">
      <div class="property-header">
        <div>
          <h3>{{ property.title }}</h3>
          <p class="location">📍 {{ property.location }}</p>
        </div>
        <button
          type="button"
          class="bookmark-btn"
          :class="{ bookmarked: property.bookmarked }"
          @click="$emit('toggle-bookmark', property.id)"
        >
          {{ property.bookmarked ? '♥' : '♡' }}
        </button>
      </div>

      <p class="property-type">{{ property.type }}</p>

      <div class="property-specs">
        <span v-if="property.bedrooms > 0" class="spec">
          <strong>{{ property.bedrooms }}</strong> bed{{ property.bedrooms !== 1 ? 's' : '' }}
        </span>
        <span v-else class="spec"><strong>Studio</strong></span>
        <span class="spec"><strong>{{ property.bathrooms }}</strong> bath{{ property.bathrooms !== 1 ? 's' : '' }}</span>
      </div>

      <div class="property-footer">
        <p class="price">R{{ property.price }}<span class="price-unit">/night</span></p>
        <button type="button" class="contact-btn">Contact</button>
      </div>
    </div>
  </article>
</template>

<script>
export default {
  name: 'PropertyCard',
  props: {
    property: {
      type: Object,
      required: true
    }
  }
};
</script>

<style scoped>
.property-card {
  display: flex;
  flex-direction: column;
  border-radius: 20px;
  background: #ffffff;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
  overflow: hidden;
  transition: transform 0.2s ease, box-shadow 0.2s ease, opacity 0.2s ease;
}

.property-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 26px 55px rgba(15, 23, 42, 0.12);
}

.property-card.unavailable {
  opacity: 0.75;
}

.property-image {
  width: 100%;
  height: 220px;
  background-size: cover;
  background-position: center;
}

.unavailable-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  background: rgba(239, 68, 68, 0.95);
  color: #ffffff;
  padding: 8px 14px;
  border-radius: 14px;
  font-weight: 700;
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.property-content {
  padding: 22px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  flex-grow: 1;
}

.property-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
}

.property-header h3 {
  margin: 0 0 6px;
  font-size: 1.3rem;
  line-height: 1.2;
}

.location {
  margin: 0;
  color: #64748b;
  font-size: 0.95rem;
}

.bookmark-btn {
  border: none;
  background: transparent;
  color: #ef4444;
  font-size: 1.6rem;
  cursor: pointer;
  padding: 0;
  transition: transform 0.2s ease;
}

.bookmark-btn:hover {
  transform: scale(1.15);
}

.bookmark-btn.bookmarked {
  color: #dc2626;
}

.property-type {
  margin: 0;
  color: #2563eb;
  font-weight: 700;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.property-specs {
  display: flex;
  gap: 16px;
  padding: 12px 0;
  border-top: 1px solid #e2e8f0;
  border-bottom: 1px solid #e2e8f0;
}

.spec {
  font-size: 0.95rem;
  color: #475569;
}

.spec strong {
  color: #111827;
}

.property-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-top: auto;
}

.price {
  margin: 0;
  font-size: 1.6rem;
  font-weight: 800;
}

.price-unit {
  font-size: 0.9rem;
  color: #64748b;
}

.contact-btn {
  border: none;
  background: #2563eb;
  color: #ffffff;
  border-radius: 12px;
  padding: 12px 18px;
  font-weight: 700;
  cursor: pointer;
  transition: transform 0.2s ease, background-color 0.2s ease;
}

.contact-btn:hover {
  background: #1d4ed8;
  transform: translateY(-1px);
}
</style>
