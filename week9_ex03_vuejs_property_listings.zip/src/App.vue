<template>
  <div class="app-shell">
    <header class="header">
      <div class="header-content">
        <h1>Homes & Beyond</h1>
        <p class="tagline">Find your perfect short-term rental in Cape Town</p>
      </div>
      <div class="header-stat">
        <span class="stat-label">Available properties</span>
        <strong class="stat-count">{{ availableCount }}</strong>
      </div>
    </header>

    <section class="controls">
      <div class="search-control">
        <input
          v-model="searchTerm"
          type="text"
          placeholder="Search by title or location..."
          class="search-input"
        />
      </div>
      <div class="sort-control">
        <button
          type="button"
          :class="['sort-btn', sortOrder]"
          @click="toggleSort"
        >
          {{ sortOrder === 'asc' ? 'Price: Low to High' : 'Price: High to Low' }}
        </button>
      </div>
    </section>

    <section class="properties-grid">
      <PropertyCard
        v-for="property in filteredAndSorted"
        :key="property.id"
        :property="property"
        @toggle-bookmark="toggleBookmark"
      />
      <div v-if="filteredAndSorted.length === 0" class="no-results">
        No properties match your search.
      </div>
    </section>
  </div>
</template>

<script>
import PropertyCard from './components/CourseCard.vue';

export default {
  name: 'App',
  components: { PropertyCard },
  data() {
    return {
      searchTerm: '',
      sortOrder: 'asc',
      properties: [
        {
          id: 1,
          title: 'Modern City Apartment',
          location: 'Bloubergstrand',
          price: 850,
          type: 'Apartment',
          bedrooms: 2,
          bathrooms: 1,
          image: 'url(data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22250%22%3E%3Crect fill=%22%232563eb%22 width=%22400%22 height=%22250%22/%3E%3C/svg%3E)',
          available: true,
          bookmarked: false
        },
        {
          id: 2,
          title: 'Seaside Villa',
          location: 'Camps Bay',
          price: 1200,
          type: 'Villa',
          bedrooms: 3,
          bathrooms: 2,
          image: 'url(data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22250%22%3E%3Crect fill=%22%2310b981%22 width=%22400%22 height=%22250%22/%3E%3C/svg%3E)',
          available: false,
          bookmarked: false
        },
        {
          id: 3,
          title: 'Trendy Loft',
          location: 'Woodstock',
          price: 650,
          type: 'Loft',
          bedrooms: 1,
          bathrooms: 1,
          image: 'url(data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22250%22%3E%3Crect fill=%22%23f59e0b%22 width=%22400%22 height=%22250%22/%3E%3C/svg%3E)',
          available: true,
          bookmarked: false
        },
        {
          id: 4,
          title: 'Garden House',
          location: 'Constantia',
          price: 950,
          type: 'House',
          bedrooms: 2,
          bathrooms: 2,
          image: 'url(data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22250%22%3E%3Crect fill=%22%238b5cf6%22 width=%22400%22 height=%22250%22/%3E%3C/svg%3E)',
          available: true,
          bookmarked: false
        },
        {
          id: 5,
          title: 'Luxury Penthouse',
          location: 'V&A Waterfront',
          price: 1600,
          type: 'Penthouse',
          bedrooms: 3,
          bathrooms: 3,
          image: 'url(data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22250%22%3E%3Crect fill=%22%23ec4899%22 width=%22400%22 height=%22250%22/%3E%3C/svg%3E)',
          available: true,
          bookmarked: false
        },
        {
          id: 6,
          title: 'Cozy Studio',
          location: 'Mowbray',
          price: 450,
          type: 'Studio',
          bedrooms: 0,
          bathrooms: 1,
          image: 'url(data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22250%22%3E%3Crect fill=%22%2306b6d4%22 width=%22400%22 height=%22250%22/%3E%3C/svg%3E)',
          available: true,
          bookmarked: false
        }
      ]
    };
  },
  computed: {
    availableCount() {
      return this.properties.filter((p) => p.available).length;
    },
    filtered() {
      const term = this.searchTerm.trim().toLowerCase();
      return this.properties.filter((prop) => {
        const matchesSearch = [prop.title, prop.location]
          .some((value) => value.toLowerCase().includes(term));
        return matchesSearch;
      });
    },
    filteredAndSorted() {
      const sorted = [...this.filtered].sort((a, b) => {
        return this.sortOrder === 'asc' ? a.price - b.price : b.price - a.price;
      });
      return sorted;
    }
  },
  methods: {
    toggleSort() {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    },
    toggleBookmark(propertyId) {
      const property = this.properties.find((item) => item.id === propertyId);
      if (property) {
        property.bookmarked = !property.bookmarked;
      }
    }
  }
};
</script>

<style>
:root {
  color: #111827;
  background: #f8fafc;
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

body {
  margin: 0;
  min-height: 100vh;
  background: linear-gradient(180deg, #f8fafc 0%, #eff6ff 100%);
}

.app-shell {
  max-width: 1280px;
  margin: 0 auto;
  padding: 32px 24px;
}

.header {
  display: grid;
  gap: 24px;
  grid-template-columns: 1fr auto;
  align-items: start;
  margin-bottom: 32px;
  padding: 32px 36px;
  border-radius: 32px;
  background: #ffffff;
  box-shadow: 0 24px 60px rgba(15, 23, 42, 0.08);
}

.header-content h1 {
  margin: 0 0 8px;
  font-size: clamp(2rem, 4vw, 3.2rem);
  line-height: 1.05;
}

.tagline {
  margin: 0;
  color: #475569;
  font-size: 1rem;
}

.header-stat {
  text-align: right;
  padding: 20px 24px;
  border-radius: 24px;
  background: #f0f9ff;
}

.stat-label {
  display: block;
  font-size: 0.9rem;
  color: #475569;
  margin-bottom: 8px;
}

.stat-count {
  display: block;
  font-size: 3rem;
  color: #111827;
}

.controls {
  display: grid;
  gap: 16px;
  grid-template-columns: 1fr auto;
  align-items: center;
  margin-bottom: 28px;
}

.search-control {
  display: grid;
  gap: 0;
}

.search-input {
  width: 100%;
  border: 1px solid #cbd5e1;
  border-radius: 16px;
  padding: 16px 20px;
  font-size: 1rem;
  outline: none;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.search-input:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

.sort-control {
  display: grid;
}

.sort-btn {
  border: 1px solid #cbd5e1;
  border-radius: 16px;
  background: #ffffff;
  color: #111827;
  padding: 16px 20px;
  font-weight: 700;
  cursor: pointer;
  transition: border-color 0.2s ease, background-color 0.2s ease;
}

.sort-btn:hover {
  border-color: #2563eb;
  background: #f0f9ff;
}

.properties-grid {
  display: grid;
  gap: 24px;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
}

.no-results {
  grid-column: 1 / -1;
  padding: 48px 24px;
  text-align: center;
  color: #64748b;
  font-size: 1.1rem;
}

@media (max-width: 840px) {
  .header {
    grid-template-columns: 1fr;
  }

  .header-stat {
    text-align: left;
  }

  .controls {
    grid-template-columns: 1fr;
  }
}
</style>
