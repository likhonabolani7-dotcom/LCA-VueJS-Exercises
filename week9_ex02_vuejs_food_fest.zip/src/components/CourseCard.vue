<template>
  <article :class="['ticket-card', { featured: tier.featured }]">
    <div class="ticket-header">
      <div>
        <p class="ticket-label">{{ tier.name }} Pass</p>
        <h2>{{ tier.name }}</h2>
      </div>

      <button
        type="button"
        class="favorite-btn"
        :class="{ active: tier.favourited }"
        @click="$emit('toggle-favourite', tier.id)"
      >
        <span class="star">{{ tier.favourited ? '★' : '☆' }}</span>
        <span>{{ tier.favourited ? 'Favourited' : 'Favourite' }}</span>
      </button>
    </div>

    <p class="ticket-description">{{ tier.description }}</p>

    <div class="ticket-meta">
      <p class="ticket-price">{{ formattedPrice }}</p>
      <span v-if="tier.featured" class="badge">Featured</span>
    </div>

    <ul class="benefits">
      <li v-for="benefit in tier.benefits" :key="benefit">
        <span class="benefit-icon">✓</span>
        {{ benefit }}
      </li>
    </ul>

    <button type="button" class="ticket-action">Notify Me</button>
  </article>
</template>

<script>
export default {
  name: 'TicketCard',
  props: {
    tier: {
      type: Object,
      required: true
    }
  },
  computed: {
    formattedPrice() {
      return new Intl.NumberFormat('en-ZA', {
        style: 'currency',
        currency: 'ZAR'
      }).format(this.tier.price);
    }
  }
};
</script>

<style scoped>
.ticket-card {
  display: flex;
  flex-direction: column;
  gap: 22px;
  padding: 28px;
  border-radius: 28px;
  background: #ffffff;
  border: 1px solid transparent;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
  min-height: 360px;
  transition: transform 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease;
}

.ticket-card:hover {
  transform: translateY(-4px);
}

.ticket-card.featured {
  background: linear-gradient(180deg, #ffffff 0%, #eff6ff 100%);
  border-color: #3b82f6;
  box-shadow: 0 26px 55px rgba(59, 130, 246, 0.15);
}

.ticket-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 18px;
  flex-wrap: wrap;
}

.ticket-label {
  margin: 0 0 10px;
  text-transform: uppercase;
  letter-spacing: 0.18em;
  font-size: 0.78rem;
  font-weight: 700;
  color: #2563eb;
}

.ticket-card h2 {
  margin: 0;
  font-size: 1.8rem;
  line-height: 1.1;
}

.favorite-btn {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  border: 1px solid #cbd5e1;
  border-radius: 18px;
  background: #ffffff;
  color: #111827;
  font-weight: 700;
  cursor: pointer;
  transition: background-color 0.2s ease, border-color 0.2s ease;
}

.favorite-btn:hover {
  border-color: #2563eb;
}

.favorite-btn.active {
  background: #2563eb;
  color: #ffffff;
  border-color: #2563eb;
}

.star {
  font-size: 1rem;
}

.ticket-description {
  margin: 0;
  color: #475569;
  line-height: 1.8;
}

.ticket-meta {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  gap: 14px;
  flex-wrap: wrap;
}

.ticket-price {
  margin: 0;
  font-size: 2rem;
  font-weight: 800;
}

.badge {
  background: #e0f2fe;
  color: #0369a1;
  padding: 10px 16px;
  border-radius: 999px;
  font-size: 0.85rem;
  font-weight: 700;
}

.benefits {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  gap: 12px;
}

.benefits li {
  display: flex;
  align-items: center;
  gap: 12px;
  color: #334155;
  font-weight: 600;
}

.benefit-icon {
  display: inline-flex;
  width: 28px;
  height: 28px;
  border-radius: 999px;
  align-items: center;
  justify-content: center;
  background: #dbeafe;
  color: #1d4ed8;
}

.ticket-action {
  margin-top: auto;
  border: none;
  background: #111827;
  color: #ffffff;
  border-radius: 18px;
  padding: 16px 20px;
  font-weight: 700;
  cursor: pointer;
  transition: transform 0.2s ease, background-color 0.2s ease;
}

.ticket-action:hover {
  background: #1f2937;
}
</style>
