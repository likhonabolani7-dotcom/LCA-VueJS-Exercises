<template>
  <div class="app-shell">
    <header class="hero">
      <div class="hero-copy">
        <p class="eyebrow">Cape Town Food Fest</p>
        <h1>Choose your festival ticket</h1>
        <p class="subtitle">
          Compare Bronze, Silver, and Gold tiers with benefits, pricing, and featured advantage
          before the big weekend.
        </p>
      </div>

      <div class="hero-panel">
        <div class="hero-stat">
          <span class="stat-label">Favourited tiers</span>
          <strong class="stat-value">{{ favouriteCount }}</strong>
        </div>
        <button type="button" class="hero-action">Notify Me</button>
      </div>
    </header>

    <section class="ticket-grid">
      <TicketCard
        v-for="tier in ticketTiers"
        :key="tier.id"
        :tier="tier"
        @toggle-favourite="toggleFavourite"
      />
    </section>
  </div>
</template>

<script>
import TicketCard from './components/CourseCard.vue';

export default {
  name: 'App',
  components: { TicketCard },
  data() {
    return {
      ticketTiers: [
        {
          id: 1,
          name: 'Bronze',
          price: 125,
          description: 'A festival pass for access to food vendors, live music, and community lounges.',
          benefits: ['General entry', 'Street food village', 'Live music stages'],
          featured: false,
          favourited: false
        },
        {
          id: 2,
          name: 'Silver',
          price: 195,
          description: 'Our most popular option with perks for faster service and comfort.',
          benefits: ['All Bronze benefits', 'Priority food lanes', '2 drink tokens', 'Merch discount'],
          featured: true,
          favourited: false
        },
        {
          id: 3,
          name: 'Gold',
          price: 295,
          description: 'VIP experience with chef meetups, lounge access, and premium swag.',
          benefits: ['All Silver perks', 'VIP lounge', 'Chef meet-and-greet', 'Complimentary swag'],
          featured: false,
          favourited: false
        }
      ]
    };
  },
  computed: {
    favouriteCount() {
      return this.ticketTiers.filter((tier) => tier.favourited).length;
    }
  },
  methods: {
    toggleFavourite(tierId) {
      const tier = this.ticketTiers.find((item) => item.id === tierId);
      if (tier) {
        tier.favourited = !tier.favourited;
      }
    }
  }
};
</script>

<style>
:root {
  color: #111827;
  background: #f8fafc;
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

body {
  margin: 0;
  min-height: 100vh;
  background: linear-gradient(180deg, #ffffff 0%, #eef2ff 100%);
}

.app-shell {
  max-width: 1180px;
  margin: 0 auto;
  padding: 32px 24px;
}

.hero {
  display: grid;
  gap: 24px;
  grid-template-columns: 1.4fr 0.8fr;
  align-items: center;
  margin-bottom: 28px;
  padding: 34px 36px;
  border-radius: 32px;
  background: #ffffff;
  box-shadow: 0 24px 60px rgba(15, 23, 42, 0.08);
}

.hero-copy {
  max-width: 640px;
}

.eyebrow {
  margin: 0 0 14px;
  text-transform: uppercase;
  letter-spacing: 0.18em;
  font-size: 0.78rem;
  color: #2563eb;
}

h1 {
  margin: 0;
  font-size: clamp(2rem, 3vw, 3.4rem);
  line-height: 1.05;
}

.subtitle {
  margin: 18px 0 0;
  color: #475569;
  line-height: 1.8;
}

.hero-panel {
  display: grid;
  gap: 18px;
  justify-items: end;
}

.hero-stat {
  background: #eef2ff;
  border-radius: 26px;
  padding: 22px 24px;
  text-align: center;
  min-width: 180px;
}

.stat-label {
  display: block;
  margin-bottom: 10px;
  color: #475569;
  font-size: 0.9rem;
  font-weight: 700;
}

.stat-value {
  margin: 0;
  font-size: 2.8rem;
  color: #111827;
}

.hero-action {
  border: none;
  background: #2563eb;
  color: #ffffff;
  border-radius: 18px;
  padding: 16px 28px;
  font-weight: 700;
  cursor: pointer;
  transition: transform 0.2s ease, background-color 0.2s ease;
}

.hero-action:hover {
  background: #1d4ed8;
  transform: translateY(-1px);
}

.ticket-grid {
  display: grid;
  gap: 24px;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
}

@media (max-width: 820px) {
  .hero {
    grid-template-columns: 1fr;
    text-align: center;
  }

  .hero-panel {
    justify-items: center;
  }
}
</style>
