# Cape Town Food Fest Landing Page

A Vue 3 single-page landing page for Cape Town Food Fest. This app displays Bronze, Silver, and Gold ticket tiers using reusable card components and local ticket data.

## Project Overview

The page presents event ticket tiers with pricing, benefits, and featured styling. Users can favourite a tier to simulate engagement while browsing a festival ticket experience.

## Features

- Dynamic ticket tier rendering from local data
- Featured tier styling to highlight the most popular pass
- Interactive favourite toggle for each ticket card
- Responsive layout for desktop and mobile
- Clean festival landing page design with call-to-action elements

## Installation

1. Open a terminal in the `vue` directory.
2. Run `npm install`.
3. Run `npm run dev`.

## Run

- Start the app with `npm run dev`
- Open the local URL shown in the terminal

## Screenshot

Add a screenshot of the finished interface here:

![Cape Town Food Fest Landing Page](screenshot.png)

## Notes

- All data is stored locally in the app.
- The page is built with Vue 3 and Vite.
