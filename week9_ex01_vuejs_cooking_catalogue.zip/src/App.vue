<template>
  <div class="app-shell">
    <header class="hero">
      <div>
        <p class="eyebrow">Cooking Masterclass</p>
        <h1>Find your next culinary workshop</h1>
        <p class="subtitle">Explore expert-led kitchen courses, compare prices, and save favourites to your wishlist.</p>
      </div>
      <div class="wishlist-card">
        <p class="wishlist-label">Wishlist</p>
        <strong :class="['wishlist-count', { pulse: wishlistPulse }]">{{ wishlistCount }}</strong>
      </div>
    </header>

    <section class="controls">
      <div class="control-item">
        <label for="search">Search courses</label>
        <input id="search" v-model="searchTerm" type="text" placeholder="Search by title, chef, or level" />
      </div>
      <div class="control-item switch-wrapper">
        <label>Show available only</label>
        <button type="button" class="toggle-btn" @click="showAvailableOnly = !showAvailableOnly">
          {{ showAvailableOnly ? 'Yes' : 'No' }}
        </button>
      </div>
    </section>

    <section class="course-grid">
      <CourseCard
        v-for="course in filteredCourses"
        :key="course.id"
        :course="course"
        @toggle-wishlist="toggleWishlist"
      />
      <div v-if="filteredCourses.length === 0" class="empty-state">
        No courses match your search. Try a different keyword.
      </div>
    </section>
  </div>
</template>

<script>
import CourseCard from './components/CourseCard.vue';

export default {
  name: 'App',
  components: { CourseCard },
  data() {
    return {
      searchTerm: '',
      showAvailableOnly: false,
      wishlistPulse: false,
      pulseTimer: null,
      courses: [
        { id: 1, title: 'Modern Pasta Workshop', chef: 'Chef Amara', price: 450, level: 'Beginner', available: true, saved: false },
        { id: 2, title: 'Art of Sourdough', chef: 'Chef Nia', price: 550, level: 'Intermediate', available: true, saved: false },
        { id: 3, title: 'Seafood Mastery', chef: 'Chef Kofi', price: 700, level: 'Advanced', available: false, saved: false },
        { id: 4, title: 'Plant-Based Bistro', chef: 'Chef Lila', price: 420, level: 'Beginner', available: true, saved: false },
        { id: 5, title: 'French Pastry Basics', chef: 'Chef Pierre', price: 650, level: 'Intermediate', available: false, saved: false },
        { id: 6, title: 'Spices & Sauces', chef: 'Chef Zuri', price: 500, level: 'Intermediate', available: true, saved: false },
        { id: 7, title: 'Grilling Essentials', chef: 'Chef Thabo', price: 480, level: 'Beginner', available: true, saved: false },
        { id: 8, title: 'Sea Salt & Smoke', chef: 'Chef Ama', price: 720, level: 'Advanced', available: true, saved: false },
        { id: 9, title: 'Dim Sum Discovery', chef: 'Chef Mei', price: 580, level: 'Intermediate', available: false, saved: false },
        { id: 10, title: 'Cocktail Pairings', chef: 'Chef Noah', price: 390, level: 'Beginner', available: true, saved: false }
      ]
    };
  },
  computed: {
    wishlistCount() {
      return this.courses.filter((course) => course.saved).length;
    },
    filteredCourses() {
      const term = this.searchTerm.trim().toLowerCase();
      return this.courses.filter((course) => {
        const matchesSearch = [course.title, course.chef, course.level]
          .some((value) => value.toLowerCase().includes(term));
        const matchesAvailable = !this.showAvailableOnly || course.available;
        return matchesSearch && matchesAvailable;
      });
    }
  },
  methods: {
    toggleWishlist(courseId) {
      const course = this.courses.find((item) => item.id === courseId);
      if (course) {
        course.saved = !course.saved;
      }
    }
  },
  watch: {
    wishlistCount() {
      this.wishlistPulse = true;
      clearTimeout(this.pulseTimer);
      this.pulseTimer = setTimeout(() => {
        this.wishlistPulse = false;
      }, 240);
    }
  }
};
</script>

<style>
:root {
  color-scheme: dark;
  color: #1f2937;
  background: #f8fafc;
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

body {
  margin: 0;
  min-height: 100vh;
  background: linear-gradient(180deg, #ffffff 0%, #f1f5f9 100%);
}

.app-shell {
  max-width: 1180px;
  margin: 0 auto;
  padding: 32px 24px;
}

.hero {
  display: grid;
  gap: 24px;
  grid-template-columns: 1fr auto;
  align-items: center;
  margin-bottom: 32px;
  padding: 28px 32px;
  border-radius: 32px;
  background: #ffffff;
  box-shadow: 0 24px 60px rgba(15, 23, 42, 0.08);
}

.eyebrow {
  margin: 0 0 12px;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  font-size: 0.79rem;
  color: #7c3aed;
}

h1 {
  margin: 0;
  font-size: clamp(2rem, 3vw, 3rem);
  line-height: 1.05;
}

.subtitle {
  margin: 16px 0 0;
  color: #475569;
  max-width: 620px;
}

.wishlist-card {
  padding: 18px 22px;
  border-radius: 24px;
  background: #27272a;
  color: #fff;
  text-align: center;
  min-width: 180px;
  box-shadow: 0 18px 30px rgba(15, 23, 42, 0.22);
}

.wishlist-label {
  margin: 0 0 8px;
  font-size: 0.86rem;
  color: #c7d2fe;
}

.wishlist-count {
  margin: 0;
  font-size: 2.6rem;
  transition: transform 0.25s ease;
}

.controls {
  display: grid;
  gap: 16px;
  grid-template-columns: 1fr auto;
  align-items: end;
  margin-bottom: 28px;
}

.control-item {
  display: grid;
  gap: 10px;
}

label {
  font-weight: 700;
  color: #0f172a;
}

input {
  width: 100%;
  border: 1px solid #cbd5e1;
  border-radius: 14px;
  padding: 14px 16px;
  font-size: 1rem;
  outline: none;
  transition: border-color 0.2s ease;
}

input:focus {
  border-color: #7c3aed;
}

.toggle-btn {
  border: 1px solid #7c3aed;
  background: #fff;
  color: #7c3aed;
  padding: 12px 18px;
  border-radius: 14px;
  cursor: pointer;
  font-weight: 700;
}

.course-grid {
  display: grid;
  gap: 24px;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
}

.empty-state {
  grid-column: 1 / -1;
  padding: 36px;
  border-radius: 24px;
  text-align: center;
  background: #e2e8f0;
  color: #334155;
  font-weight: 600;
}

@media (max-width: 720px) {
  .hero {
    grid-template-columns: 1fr;
  }

  .controls {
    grid-template-columns: 1fr;
  }
}
</style>
