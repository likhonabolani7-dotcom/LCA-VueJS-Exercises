<template>
  <article class="course-card">
    <div class="course-meta">
      <h2>{{ course.title }}</h2>
      <p class="chef">by {{ course.chef }}</p>
      <span class="level" :class="course.level.toLowerCase()">{{ course.level }}</span>
    </div>

    <div class="course-details">
      <p class="price">{{ formattedPrice }}</p>
      <span class="status" :class="course.available ? 'available' : 'sold-out'">
        {{ course.available ? 'Available' : 'Sold Out' }}
      </span>
    </div>

    <button
      type="button"
      class="wishlist-btn"
      :class="{ saved: course.saved }"
      @click="$emit('toggle-wishlist', course.id)"
    >
      {{ course.saved ? 'Saved' : 'Save to Wishlist' }}
    </button>
  </article>
</template>

<script>
export default {
  name: 'CourseCard',
  props: {
    course: {
      type: Object,
      required: true
    }
  },
  computed: {
    formattedPrice() {
      return new Intl.NumberFormat('en-ZA', {
        style: 'currency',
        currency: 'ZAR'
      }).format(this.course.price);
    }
  }
};
</script>

<style scoped>
.course-card {
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 26px;
  border-radius: 24px;
  background: #ffffff;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
  min-height: 260px;
}

.course-meta h2 {
  margin: 0;
  font-size: 1.4rem;
}

.chef {
  margin: 8px 0 0;
  color: #64748b;
}

.level {
  display: inline-flex;
  padding: 8px 12px;
  border-radius: 999px;
  font-size: 0.82rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

.level.beginner {
  background: #e0f2fe;
  color: #0369a1;
}

.level.intermediate {
  background: #ede9fe;
  color: #7c3aed;
}

.level.advanced {
  background: #fee2e2;
  color: #b91c1c;
}

.course-details {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  flex-wrap: wrap;
}

.price {
  margin: 0;
  font-size: 1.25rem;
  font-weight: 700;
}

.status {
  padding: 8px 14px;
  border-radius: 999px;
  font-size: 0.85rem;
  font-weight: 700;
}

.status.available {
  background: #ecfdf5;
  color: #166534;
}

.status.sold-out {
  background: #f8d7da;
  color: #842029;
}

.wishlist-btn {
  margin-top: auto;
  border: none;
  padding: 14px 18px;
  border-radius: 14px;
  background: #7c3aed;
  color: #ffffff;
  font-weight: 700;
  cursor: pointer;
  transition: transform 0.2s ease, background-color 0.2s ease;
}

.wishlist-btn:hover {
  transform: translateY(-1px);
}

.wishlist-btn.saved {
  background: #0f172a;
}
</style>
