# Cooking Masterclass Catalogue

# Cooking Masterclass Catalogue

A Vue 3 single-page catalogue prototype for Cooking Masterclass. The app displays cooking workshops with chef names, course levels, prices, availability status, and a wishlist counter.

## Project Overview

This app showcases a responsive course catalogue with interactive cards. Users can browse available cooking classes, see sold out status clearly, and save favorite sessions to a wishlist.

## Features

- Dynamic course listing from local data
- Wishlist count in the header
- Sold out status label for unavailable classes
- Search and availability filter
- Responsive layout for desktop and mobile
- Clean, branded styling with minimal UI

## Installation

1. Open a terminal in the `vue` directory.
2. Run `npm install`.
3. Run `npm run dev`.

## Run

- Start the app with `npm run dev`
- Open the local URL shown in the terminal

## Screenshot

Add a screenshot of the finished interface here:

![Cooking Masterclass Catalogue](screenshot.png)

## Notes

- The app is built with Vue 3 and Vite.
- No backend or external API is required.
